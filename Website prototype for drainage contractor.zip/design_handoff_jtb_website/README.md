# Handoff: JTB Enterprises website (jtbenterprises.ca)

## Overview
Marketing site for JTB Enterprises, an excavation, drainage and landscape contractor in Maple Ridge, BC (owner Joe Buckles, since 2007). The goal is **phone calls and estimate requests**. The phone number, 604-230-8553, must be the most visible element on every page and must be a tappable `tel:+16042308553` link everywhere.

This package contains the finished **Home page** design. The Drainage, Projects, About and Contact pages still need to be built in the same visual system. Their content specs are listed below.

## About the design files
`Home.dc.html` is a **design reference built in HTML**. It is a prototype that shows the intended look and behavior. It is not production code to copy. Open it in a browser with `support.js` alongside it. Rebuild it in the target stack. If no codebase exists yet, a good fit is Astro or Next.js (static output) with plain CSS or Tailwind, deployable to Netlify or Vercel. The site is content-heavy, needs very little JS, and SEO matters.

Inside the file, the markup is the template, and the `class Component` script at the bottom holds the data arrays (services, problems, reviews, projects) and the small amount of interaction state. All styles are inline. Pull them into proper CSS or components.

## Fidelity
**High fidelity.** Colors, type, spacing, copy and interactions are final. Recreate them as closely as possible.

## Design tokens

### Colors
| Token | Hex | Use |
|---|---|---|
| paper | `#F3F1EC` | Page background, header background |
| ink | `#16150F` | Text, borders, dark sections (problems, CTA, footer), dark button |
| blue | `#2238F0` | Accent: phone number, primary button, guarantee section background, active states |
| blue-light | `#8C9BFF` | Accent on dark backgrounds (phone in CTA, links, +/− signs) |
| body-2 | `#3B3832` | Secondary body text on paper |
| muted | `#5E5A52` | Small labels and meta text on paper |
| muted-2 | `#8A847A` | De-emphasized words inside big statements, footer legal line |
| inactive | `#A39D92` | Unselected service names |
| rule | `#D8D2C6` | Light dividers, image placeholder background |
| on-dark | `#CFCAC0` | Body text on ink |
| on-dark-muted | `#A9A397` | Meta text on ink |
| footer-rule | `#3A372F` | Footer top border |

Photos are shown **full color, with no overlays or filters**.

### Typography
- One family: **Schibsted Grotesk** (Google Fonts), weights 400/500/600/700/800/900.
- Body: 18px / 1.5, weight 400.
- Headlines use weight 800, tight tracking and tight leading. Use **sentence case, never all caps**.
  - H1: `clamp(50px, 7.4vw, 128px)`, line-height .92, letter-spacing -.055em, `text-wrap: balance`
  - H2 (section): `clamp(44px, 5.4vw, 88px)`, lh .94, ls -.05em
  - Guarantee H2: `clamp(46px, 6.8vw, 116px)`, lh .92, ls -.055em
  - Big statement paragraphs (proof, service area): weight 600–700, `clamp(28px, 3.6vw, 54px)`, lh 1.08–1.12, ls -.035 to -.045em
  - Service names: weight 800, `clamp(40px, 5.2vw, 84px)`, lh .95, ls -.05em
  - Header phone: weight 800, 28px, ls -.03em, blue
  - Logo "JTB": weight 900, 28px, ls -.05em
- Small text is never below 15px.

### Shape and lines
- Border radius is **2px** on buttons and **0** everywhere else.
- Structural rules are `1.5px solid #16150F`. Light dividers are `1px solid #D8D2C6`.
- There are **no shadows, gradients, cards, pills, icons or numbered labels.** That is a deliberate choice: the brief rejected the "AI template" look.

### Layout
- Content max-width is 1520px. Side padding is `clamp(16px, 3vw, 40px)`.
- Section vertical padding is `clamp(56px, 7vw, 110px)`. The guarantee and CTA bands use `clamp(64px, 8vw, 130px)`.
- Two-column sections use `grid-template-columns: repeat(auto-fit, minmax(min(100%, 520–560px), 1fr))` with a column gap of `clamp(32px, 5vw, 96px)`, so they stack naturally on narrow screens.
- The breakpoint is **1100px**. Below it, the desktop nav and header CTA are hidden, the header shows only the logo and the tappable phone number, and a sticky bottom bar appears.

## Home page, section by section

1. **Header** (sticky, 76px tall, paper background, 1.5px ink bottom border)
   - Left: "JTB" (900 weight) followed by "Excavation & Drainage" (15px, 500 weight, muted).
   - Nav: Drainage, Excavation, Landscaping, Projects, About, Contact (17px, 500 weight, gap 28px). Links turn blue on hover.
   - Then "Call Joe / direct" in two lines (15px, muted, right-aligned) beside **604-230-8553** (28px, 800 weight, blue).
   - Then the button **"Request an Estimate"**: ink background, paper text, 600 weight, 17px, padding 14px 20px. Turns blue on hover.

2. **Hero**
   - Two columns, bottom-aligned. Left is the H1: "Excavation and drainage done right, guaranteed for life."
   - Right column has:
     - The subhead (20px, body-2): "Foundation drainage, wet basements, site prep, rock walls and land clearing across the Lower Mainland and Fraser Valley. Owner-operated by Joe Buckles since 2007."
     - A **job picker box** (white background, 1.5px ink border):
       - Title row: "What's going on at your place?"
       - Four rows, each with a label on the left and a hint plus "→" on the right:
         - Water in the basement (Drainage)
         - Yard or driveway won't drain (Drainage)
         - Clearing or prepping a lot (Site work)
         - Slope, wall or landscaping (Walls)
       - Rows turn blue with white text on hover. Each row should link to the estimate form with the project type pre-selected.
       - Bottom of the box: two flush buttons side by side, **Call 604-230-8553** (blue) and **Request an Estimate** (ink).
   - Below the two columns: a full-width photo at 16:7 aspect ratio, min height 340px.
     - A caption is tucked into the bottom-left corner on a paper background (16px): bold "Pitt Meadows, last month." followed by "Full perimeter drain on a 1978 rancher. Camera Monday, dug Tuesday, backfilled and seeded Friday."

3. **Proof statement**
   - One large sentence, with partial colouring: "Over 800 jobs since 2007. **4.9 on Google** (blue) from 74 reviews, a Consumer Choice Award, a Canadian Business Award, HomeStars-reviewed, and **WCB covered on every site.** (muted-2)"
   - Underneath: links to "Read the Google reviews" and "HomeStars profile".
   - Real award and review logos can sit in a plain row here later, with no cards.

4. **"Water where it shouldn't be?"** (ink background)
   - Left: photo of the drain camera, min height 560px.
   - Right: H2, then an **accordion** of three problems. The first is open by default, and only one can be open at a time. Each row has a 1.5px paper top border, the title at 22–28px / 700 weight, and "+" or "−" in blue-light.
     - Wet or flooding basement: "Most wet basements in the valley come back to a perimeter drain that's crushed, root-bound or was never put in right. We dig to the footing, replace the tile and membrane, and get the water away from the house." Link: "Wet basement repair".
     - Standing water in the yard or driveway: "Clay soil and flat grading hold water for weeks after a Fraser Valley rain. We regrade, put in french drains or catch basins, and tie them to storm or a rock pit." Link: "Yard drainage".
     - Failed or clogged perimeter drains: "Houses built before 1990 often have clay or corrugated tile that's collapsed or silted shut. Sometimes it flushes clean, sometimes it needs replacing. The camera tells us which." Link: "Perimeter drain replacement".
   - Closing line, pinned to the bottom: "We scope the line with a camera before we dig, so you only pay for the fix you need." followed by "$350 flat, credited to the job." in blue-light.

5. **Services**
   - Intro line: "What we do. Same crew on every one, nothing subbed out."
   - Left: three large service names stacked, each with a 1.5px ink top border and a one-line description underneath.
     - The active one is ink and the others use the inactive colour. **Hover or click changes the active service.**
   - Right column is sticky at `top: 100px`. It shows the active service's 4:3 photo, its included-list in two columns (rows with 1px rule underlines), its guarantee line in blue/700 weight, and a "Learn more about …" link.
   - Service data:
     - **Drainage.** Line: "Wet basements, perimeter drains, camera inspection". List: Perimeter and foundation drainage; Wet basement remediation; Drain camera inspection; Sump pits and pumps; French drains; Storm connections. Guarantee: "Lifetime guarantee on foundation drainage".
     - **Excavation and site work.** Line: "Acreage prep, clearing, septic, roads". List: Site prep; Land clearing; Demolition; Septic installation; Access roads; Driveways and parking pads; Erosion control; Property cleanup. Guarantee: "Written workmanship guarantee".
     - **Walls and landscaping.** Line: "Rock walls set by machine, grading, hardscape". List: Rock walls; Retaining walls; Hardscaping; Grading; Drainage-first landscaping for rural lots. Guarantee: "Lifetime guarantee on rock walls".

6. **Equipment and crew**
   - On a 12-column grid: a 3:2 photo (8 columns) and a 4:5 photo (4 columns). Both go full width below 800px.
   - Below: H2 "Joe's on every job. We don't sub out the dig." beside a definition list:
     - Machines: Kubota KX057 and KX080, Cat 314 with thumb, 1.7 t mini for tight side yards
     - Trucks: Two tandem dumps, 20 ft tilt deck to float the machines
     - Coverage: WCB covered, fully insured, clearance letter sent with every quote
     - On site: Joe quotes it and runs it. Same crew start to finish.

7. **Recent jobs** (1.5px ink top border)
   - H2 "Recent jobs", with "All 800+ projects" linked on the right.
   - Before/after: two 4:3 photos side by side, captioned "Before" and "After". Then: "**Maple Ridge.** Overgrown back acreage cleared, stumped and graded, ready for a shop pad. 5 days."
   - Then three 4:5 project tiles, each with a photo and a line of text below:
     - **Maple Ridge.** 2 acre clearing, driveway and septic for a new build. 3 weeks.
     - **Abbotsford.** 90 ft rock retaining wall, 6 ft high, on a sloped back yard. 6 days.
     - **Port Coquitlam.** Camera found one collapsed side. Replaced 48 ft of tile, not the whole house. 2 days.

8. **Guarantee** (blue background, white text)
   - H2: "All our work is guaranteed. Foundation drainage and rock walls are guaranteed for life."
   - Two 20px paragraphs:
     - "If a drain we put in plugs or a rock wall we built moves, we come back and fix it. No charge, for as long as you own the house."
     - "Everything else carries a written workmanship guarantee, spelled out on your quote before a machine shows up."

9. **Reviews**
   - Left:
     - A giant "4.9" (800 weight, up to 120px).
     - "Average from 74 Google reviews." with links to Google and HomeStars.
     - Square 56px prev/next buttons (1.5px ink border, invert on hover) and an "n of 3" counter.
   - Right: one quote at 26–44px / 500 weight, followed by the name and job type. The buttons cycle through the reviews and wrap around at the ends.
   - Reviews:
     - Mark T., Pitt Meadows (Perimeter drain): "Our basement flooded twice before we called JTB. Joe came out the same week, scoped the drain tile, and had the perimeter replaced in four days. Dry ever since."
     - Sandeep K., Abbotsford (Clearing and septic): "We bought five acres of alder and blackberry. Joe cleared it, cut in a 400 foot driveway and put in the septic. Our builder said it was the cleanest pad he'd been handed."
     - Lisa M., Langley (Rock wall): "Three quotes for a rock wall and Joe was the only one who talked about drainage behind it. Two winters on and it hasn't moved an inch."
   - **Replace these with real Google and HomeStars reviews before launch.**

10. **Service area**
    - Intro line: "Yard on 284 Street in Maple Ridge. We float machines to:"
    - Then one large sentence: "Maple Ridge, Pitt Meadows, Mission, Abbotsford, Langley, Surrey, Coquitlam, Port Coquitlam and Chilliwack." ("and" is in muted-2)
    - No map embed.

11. **CTA** (ink background)
    - H2: "Tell us about the job. Estimates are free and Joe answers the phone."
    - Beside it: a giant phone number (up to 92px, blue-light), the buttons "Request an Estimate" (blue) and "joe@jtbenterprises.ca" (outlined), and the line "Most calls returned same day. Mon to Sat, 7am to 6pm."

12. **Footer** (ink background), four columns:
    - JTB Enterprises, 11417 284 Street, Maple Ridge, BC
    - Phone, email, hours
    - Nav links
    - Facebook / Instagram / LinkedIn
    - Bottom line: "Consumer Choice Award · Canadian Business Awards · HomeStars · Google 4.9 · WCB covered · © 2026 JTB Enterprises Ltd."

13. **Mobile sticky bar** (below 1100px)
    - Fixed to the bottom, two equal halves, 60px tall: **Call Joe** (blue, `tel:` link) and **Request Estimate** (ink).
    - Add 60px of bottom padding to the page so the bar doesn't cover content.

## Interactions and state
- `openProblem`: index of the open accordion row, default 0. Clicking a row toggles it, and only one can be open.
- `activeService`: default 0. Set on hover and on click/tap.
- `reviewIndex`: prev/next buttons cycle through the reviews and wrap around.
- Viewport width drives the 1100px breakpoint. Use a CSS media query in production.
- The hero job picker rows should deep-link to `/contact?type=…`.
- Hover states: nav links turn blue; buttons swap between ink and blue; picker rows get a blue background with white text.
- No animations are required.

## Pages still to build (same system)
- **Drainage** (the most important page)
  - Hero photo: open trench with new tile. H1: "Foundation and perimeter drainage, guaranteed for life."
  - Sections:
    - Signs you have a drainage problem (checklist)
    - How we diagnose it: camera inspection, **$350 flat rate, credited to the job**. Their camera has 200 ft of reach plus a sonic locator.
    - What we install: 4" PVC perforated tile, ¾" clear drain rock with filter fabric, dimple membrane, cleanouts, sump, storm tie-in
    - Why it fails: clay, roots, old tile, bad grading
    - The guarantee
    - Typical range: **$9,000–$28,000** for a full perimeter replacement, depending on house size and access
    - Three drainage reviews
    - A gallery of four photos
    - Estimate CTA with the phone number
- **Projects**
  - A grid of 12 tiles, filterable by Drainage / Excavation / Walls / Landscaping / Rural-Acreage.
  - Each tile opens a case with before/after photos, city, scope, equipment and duration.
- **About**
  - Joe on a machine.
  - A first-person story: started in 2007 with one excavator, now 800+ jobs, still on every dig.
  - How we work: we answer the phone, fixed quotes, camera before shovel, clean up daily.
  - Awards and WCB.
- **Contact / Request an Estimate**
  - Form fields:
    - Name, phone, email, city
    - Project type: Drainage / wet basement; Excavation or site prep; Land clearing or demolition; Septic; Retaining or rock wall; Landscaping; Other
    - Rough budget
    - Description
    - Photo upload
  - Right column:
    - The phone number, large
    - Email, address, hours
    - "Estimates are free. Most calls are returned same day."
  - No chatbot and no map.

## Copy rules
Write like Joe talks: short, plain and specific. Name the equipment, the materials and the cities. Never use "vision", "transform", "excellence", "partner", "seamless", "dedicated to delivering", "trusted", or "exceeding expectations".

## Assets
All photos are JTB's own job photos, hotlinked from their current Wix site (`static.wixstatic.com/media/202860_…`). **Download the originals and self-host them**, as WebP or AVIF with responsive `srcset`. The URLs are in `Home.dc.html`. The Wix size parameters (`/v1/fill/w_…`) can be stripped to get the full-size image.
- Hero: mini excavator in a perimeter drain trench beside a house (`d20a28d8…`)
- Problems: drain camera reel (`c3ed4eaa…`)
- Services:
  - Drainage: trench beside a house (`2781f057…`)
  - Excavation: excavator pulling a stump (`ebf45ad6…`)
  - Walls: excavator setting a rock wall (`f52228c7…`)
- Crew: fleet of excavators (`17f6967f…`, .jpg) and an excavator beside a house (`59446177…`)
- Before/after: land clearing (`b1651423…` / `0b40e7df…`)
- Projects: site prep (`2003b830…`), rock wall (`6f979889…`), drain trench (`26229e17…`)
- Still needed from Joe: a photo of Joe himself, and real award, review and WCB logos.

## Files
- `Home.dc.html`: the Home page design reference. Open it in a browser next to `support.js`.
- `support.js`: the runtime needed to open the reference file. Not for production.

## To verify with the client before launch
Several details are plausible placeholders and need confirming:
- The machine list
- The $350 camera fee and the $9k–$28k price range
- The project cities and durations
- The hero caption
- The review text
